(function () {
  var cfg = window.RIDENCT || {};
  var page = document.body.getAttribute("data-page") || "";

  var links = [
    ["index.html", "Accueil", "home"],
    ["fonctionnalites.html", "Fonctionnalités", "features"],
    ["communaute.html", "Communauté", "community"],
    ["securite.html", "Sécurité", "security"],
    ["faq.html", "FAQ", "faq"]
  ];

  var nav = links.map(function (l) {
    return '<li><a href="' + l[0] + '"' + (l[2] === page ? ' aria-current="page"' : "") + ">" + l[1] + "</a></li>";
  }).join("");

  var header =
    '<header class="site-header"><div class="wrap nav">' +
    '<a class="brand" href="index.html"><img src="assets/img/icon-192.png" alt="" width="36" height="36">RideNCT</a>' +
    '<ul class="nav-links" id="nav-links">' + nav +
    '<li><a class="btn btn-primary btn-small" href="contact.html">Être prévenu</a></li></ul>' +
    '<button class="menu-btn" id="menu-btn" aria-label="Ouvrir le menu" aria-expanded="false">☰</button>' +
    "</div></header>";

  var year = new Date().getFullYear();
  var owner = cfg.editeur && cfg.editeur.indexOf("À compléter") !== 0 ? cfg.editeur : "RideNCT";
  var footer =
    '<footer class="site-footer"><div class="wrap">' +
    '<div class="foot-cols">' +
    '<div><a class="brand" href="index.html"><img src="assets/img/icon-192.png" alt="" width="36" height="36">RideNCT</a><p>L\'application des motards : navigation, intercom, communauté, sécurité et atelier.</p></div>' +
    '<div><h4>Découvrir</h4><ul><li><a href="fonctionnalites.html">Fonctionnalités</a></li><li><a href="communaute.html">Communauté</a></li><li><a href="securite.html">Sécurité</a></li><li><a href="faq.html">FAQ</a></li></ul></div>' +
    '<div><h4>Informations</h4><ul><li><a href="contact.html">Contact</a></li><li><a href="mentions-legales.html">Mentions légales</a></li><li><a href="mentions-legales.html#confidentialite">Confidentialité</a></li></ul></div>' +
    '</div><div class="foot-bottom">© ' + year + " " + owner + ". Tous droits réservés.</div></div></footer>";

  var h = document.getElementById("site-header");
  var f = document.getElementById("site-footer");
  if (h) h.outerHTML = header;
  if (f) f.outerHTML = footer;

  var btn = document.getElementById("menu-btn");
  var list = document.getElementById("nav-links");
  if (btn && list) {
    var setMenu = function (open) {
      list.classList.toggle("open", open);
      btn.setAttribute("aria-expanded", open ? "true" : "false");
      btn.textContent = open ? "✕" : "☰";
    };
    btn.addEventListener("click", function () { setMenu(!list.classList.contains("open")); });
    list.addEventListener("click", function (e) { if (e.target.closest("a")) setMenu(false); });
    document.addEventListener("keydown", function (e) { if (e.key === "Escape") setMenu(false); });
  }

  // Boutons de téléchargement : actifs seulement si un lien est renseigné
  document.querySelectorAll("[data-store]").forEach(function (a) {
    var url = a.getAttribute("data-store") === "ios" ? cfg.iosUrl : cfg.androidUrl;
    if (url) {
      a.href = url;
    } else {
      a.href = "contact.html";
      a.insertAdjacentHTML("beforeend", ' <small style="opacity:.8">· bientôt</small>');
    }
  });

  // Apparition au scroll
  var items = document.querySelectorAll(".reveal");
  if ("IntersectionObserver" in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); }
      });
    }, { threshold: 0.12 });
    items.forEach(function (el) { io.observe(el); });
  } else {
    items.forEach(function (el) { el.classList.add("in"); });
  }

  // Formulaire de contact
  var form = document.getElementById("contact-form");
  if (form) {
    var msg = document.getElementById("form-msg");
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      if (form.website && form.website.value) return;
      var data = new FormData(form);
      var name = (data.get("name") || "").toString().trim();
      var email = (data.get("email") || "").toString().trim();
      var topic = (data.get("topic") || "").toString();
      var text = (data.get("message") || "").toString().trim();
      if (!name || !email || !text) {
        msg.className = "form-msg err";
        msg.textContent = "Renseigne ton nom, ton e-mail et un message.";
        return;
      }
      if (cfg.formEndpoint) {
        fetch(cfg.formEndpoint, { method: "POST", body: data, headers: { Accept: "application/json" } })
          .then(function (r) {
            if (!r.ok) throw new Error();
            form.reset();
            msg.className = "form-msg ok";
            msg.textContent = "Message envoyé. Merci !";
          })
          .catch(function () {
            msg.className = "form-msg err";
            msg.textContent = "L'envoi a échoué. Réessaie ou écris-nous directement par e-mail.";
          });
      } else {
        var subject = encodeURIComponent("[RideNCT] " + topic);
        var body = encodeURIComponent(text + "\n\n" + name + " — " + email);
        window.location.href = "mailto:" + cfg.email + "?subject=" + subject + "&body=" + body;
        msg.className = "form-msg ok";
        msg.textContent = "Ton application de messagerie va s'ouvrir avec le message prêt à envoyer.";
      }
    });
  }

  // Mentions légales : champs configurables
  document.querySelectorAll("[data-cfg]").forEach(function (el) {
    var v = cfg[el.getAttribute("data-cfg")];
    if (v) el.textContent = v;
  });
})();
